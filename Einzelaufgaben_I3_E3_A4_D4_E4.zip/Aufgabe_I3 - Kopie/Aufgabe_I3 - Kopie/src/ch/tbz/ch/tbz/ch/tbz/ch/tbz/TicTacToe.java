package ch.tbz;

// Tic-Tac-Toe Spiel mit zwei Spielern (X und O)
public class TicTacToe {
  // =========================
  // Globale Variablen (Prozessdaten)
  // =========================

  // Zeichen für das Spielfeld
  private static final char EMPTY = '-'; // Leeres Feld
  private static final char PLAYER_X = 'X'; // Spieler X
  private static final char PLAYER_O = 'O'; // Spieler O

  // Spielfeld als 2D-Array, initial leer
  private static char[][] board = {
      { EMPTY, EMPTY, EMPTY },
      { EMPTY, EMPTY, EMPTY },
      { EMPTY, EMPTY, EMPTY }
  };

  // Der Spieler, der aktuell am Zug ist
  private static char currentPlayer = PLAYER_X;

  // =========================
  // Hauptmethode (Programmstart)
  // =========================
  public static void main(String[] args) {
    System.out.println("Willkommen zu Tic-Tac-Toe!");
    printBoard(); // Zeigt das Spielfeld an

    // Hauptspielschleife
    while (true) {
      // Eingabeaufforderung für den Spieler
      String input = inputString(
          "\nSpieler " + currentPlayer + ", gib deine Position (Wähle zwischen 1, 2 oder 3 für Zeile und Spalte): ");

      // Eingabe validieren (nur 1-3 für Zeile und Spalte zulässig)
      if (input.matches("[1-3] [1-3]")) {
        // Eingabe in Array-Indizes umwandeln (1 wird zu 0, 2 zu 1, 3 zu 2)
        int row = Character.getNumericValue(input.charAt(0)) - 1;
        int col = Character.getNumericValue(input.charAt(2)) - 1;

        // Prüfen, ob das Feld noch leer ist
        if (board[row][col] == EMPTY) {
          board[row][col] = currentPlayer; // Zug setzen
          printBoard(); // Spielfeld anzeigen

          // Prüfen, ob der Spieler gewonnen hat
          if (checkWin()) {
            System.out.println("\nSpieler " + currentPlayer + " hat gewonnen!");
            break;
          }
          // Prüfen auf Unentschieden
          else if (isBoardFull()) {
            System.out.println("\nUnentschieden!");
            break;
          }

          // Spieler wechseln
          currentPlayer = (currentPlayer == PLAYER_X) ? PLAYER_O : PLAYER_X;
        } else {
          System.out.println("Ungültiger Zug, versuche es erneut.");
        }
      } else {
        System.out.println("Bitte gib eine gültige Position ein (z.B. 1 2).");
      }
    }
  }

  // =========================
  // Funktionen (Methoden)
  // =========================

  /**
   * Gibt das aktuelle Spielfeld in der Konsole aus.
   */
  private static void printBoard() {
    System.out.println("\nAktuelles Spielfeld:");
    for (char[] row : board) {
      for (char cell : row) {
        System.out.print(cell + " ");
      }
      System.out.println();
    }
  }

  /**
   * Überprüft, ob der aktuelle Spieler gewonnen hat.
   * 
   * @return true, wenn der Spieler gewonnen hat, sonst false
   */
  private static boolean checkWin() {
    for (int i = 0; i < 3; i++) {
      // Horizontale und vertikale Überprüfung
      if (board[i][0] == currentPlayer && board[i][1] == currentPlayer && board[i][2] == currentPlayer)
        return true;
      if (board[0][i] == currentPlayer && board[1][i] == currentPlayer && board[2][i] == currentPlayer)
        return true;
    }
    // Diagonale Überprüfung
    return (board[0][0] == currentPlayer && board[1][1] == currentPlayer && board[2][2] == currentPlayer) ||
        (board[0][2] == currentPlayer && board[1][1] == currentPlayer && board[2][0] == currentPlayer);
  }

  /**
   * Prüft, ob das Spielfeld komplett gefüllt ist.
   * 
   * @return true, wenn das Spielfeld voll ist, sonst false
   */
  private static boolean isBoardFull() {
    for (char[] row : board) {
      for (char cell : row) {
        if (cell == EMPTY) {
          return false;
        }
      }
    }
    return true;
  }

  /**
   * Liest eine Eingabe von der Konsole ein.
   * 
   * @param prompt Die Eingabeaufforderung, die angezeigt wird.
   * @return Die vom Benutzer eingegebene Zeichenkette
   */
  private static String inputString(String prompt) {
    System.out.print(prompt);
    java.io.Console console = System.console();
    if (console != null) {
      return console.readLine();
    } else {
      try {
        byte[] inputBytes = new byte[100];
        int length = System.in.read(inputBytes);
        return new String(inputBytes, 0, length).trim();
      } catch (Exception e) {
        return "";
      }
    }
  }
}
